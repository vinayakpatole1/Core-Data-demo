//
//  ViewController.swift
//  coreDataDemo
//
//  Created by Apple on 18/07/18.
//  Copyright © 2018 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController, dataPass{

    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var txtMobile: UITextField!
    var i = Int()
    var isUpdate = Bool()
    
    @IBAction func saveClicked(_ sender: Any) {
        
        let dict = ["name":txtName.text,"address":txtAddress.text,"city":txtCity.text,"mobile":txtMobile.text] as [String : Any]
        
        if isUpdate{
            DatabaseHelper.shareInstance.editData(object: dict as! [String : String], i: i)
            
            
        }else{
               DatabaseHelper.shareInstance.save(object: dict as! [String : String])
        }
        
    }
    
    @IBAction func showClicked(_ sender: Any) {
        
        let showvc = self.storyboard?.instantiateViewController(withIdentifier: "ListViewController") as! ListViewController
        showvc.delegate = self
        navigationController?.pushViewController(showvc, animated: true)
    }
    
    func data(object : [String : String], index : Int, isEdit : Bool)
    {
        txtName.text = object["name"]
        txtAddress.text = object["address"]
        txtCity.text = object["city"]
        txtMobile.text = object["mobile"]
        i = index
        isUpdate = isEdit
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

